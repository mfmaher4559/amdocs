# Hints

Hints are one of Cassandra’s data-repair mechanisms. When a coordinator receives a mutation but cannot deliver it to a replica because that node is down or unavailable for maintenance, the coordinator stores temporary hints on its local filesystem. When the replica is reachable again, the coordinator replays those hints so the missed mutations are applied. That process helps restore consistency across the cluster. The hints subsystem has limits: hints consume disk space and cannot grow without bound. For that reason, hints are retained only for a configurable maximum outage duration, known as the **hint window**. The ADS-DB cluster default for this window is three days.


## Monitoring

You can monitor how quickly hints are written and how much hint data is stored on disk in the **Mission Control Cluster** Grafana dashboard.

![Hints storage metrics](../images/storage-metrics-hints.png)

On each node, you can see how many hints are pending for every unreachable peer using:

```
---------------
Mon May  4 13:50:07 UTC 2026 : db-dc1-rack1-sts-0 $ nodetool listendpointspendinghints
---------------

Host ID                              Address   Rack  DC  Status Total hints Total files Newest                  Oldest
0ea3067c-86ec-4beb-bb69-5c3e8202ff26 10.3.8.50 rack1 dc3 DOWN   3170247     18          2026-05-04 13:49:17,644 2026-05-04 13:34:03,061
```

When the peer comes back online, pending hint counts drop as hints are delivered.

```
---------------
Mon May  4 14:05:51 UTC 2026 : db-dc1-rack1-sts-0 $ nodetool listendpointspendinghints
---------------

Host ID                              Address   Rack  DC  Status Total hints Total files Newest                  Oldest
0ea3067c-86ec-4beb-bb69-5c3e8202ff26 10.3.8.11 rack1 dc3 UP     1117007     7           2026-05-04 13:54:00,531 2026-05-04 13:49:17,644
```

At the same time, the **Hints** section of the **Mission Control Cluster** Grafana dashboard shows hint replay rate. When delivery has finished, the succeeded-hints metric falls back to zero.

![Hints replay metrics](../images/hints-metrics.png)

When replay is complete, `nodetool` reports that this node has no pending hints for other endpoints:

```
---------------
Mon May  4 14:15:25 UTC 2026 : db-dc1-rack1-sts-0 $ nodetool listendpointspendinghints
---------------

This node does not have hints for other endpoints
```


