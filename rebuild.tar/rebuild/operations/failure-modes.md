# Troubleshooting and Monitoring Failure Modes

## Overview

This page describes potential failure modes of the Usage database when deployed on a public cloud platform. It explains what the operations team can expect and how to monitor recovery.

## System Context Diagram

![System Context Diagram](../images/img_aoc_datastax_multi_region_dse_container_diagram_combined_CP.png)

## Topology and Redundancy

The Usage database is deployed in a multi-region, multi-availability zone (AZ) configuration.

- Each region has three Availability Zones (AZs).
- Each AZ has at least three pods running the database.
- Each database pod uses a replication factor of 3, with rack-aware NetworkTopologyStrategy for redundancy.
- The READ or WRITE consistency is set to `LOCAL_QUORUM`.
  - Strong consistency – A write is recorded to the commit log and `memtable` on a quorum of replica nodes in the same datacenter as the coordinator. This avoids latency from inter-datacenter communication.
  - See [here](https://docs.datastax.com/en/cassandra-oss/3.x/cassandra/dml/dmlConfigConsistency.html) for details on consistency levels.

With this configuration:

- A region can tolerate any single node outage and still have two full copies of the data available.
  - The replication factor of 3 per region ensures two or three copies remain available for the given data and the quorum is satisfied.
- A region can tolerate a single AZ outage and still have two full copies of the data available.
  - NetworkTopologyStrategy ensures each AZ holds only one copy of any data slice.
  - If AZ 1 goes down, AZ 2 and AZ 3 each have a full copy, so the quorum is still satisfied.
- The solution can tolerate the loss of a single region and still have three full copies of the data available.
  - The database continues to operate even if one region goes down.
  - However, switching the active data center to the passive one requires manual failover by the operations team.

## Storage

Database pods use highly available storage, such as Premium SSD version 2 (Azure) or GP3 (AWS), to prevent data loss during node failure.

## Failure Modes

### Network Failure – Inter-data Center

The Usage database manages network failures between data centers. During a network partition, the database operates in both data centers, keeping data accessible. Cross-datacenter replication and control channels are unavailable. Database writes continue to the active data center, which holds the master copy.

![Network Failure](../images/multi-region-dse-container-diagram-combined-CP-inter-dc-failure.png)

#### Behavior

The active data center manages inserts, updates, queries, etc. These changes must be sent to the passive data center. Normally, this happens asynchronously, but if the network is down, changes are written as hints on the active data center.

The control plane is also affected. Any updates to the `Mission Control Cluster` object are not propagated to the `Cassandra Datacenter` in the data plane region. If updates to the data plane region are required during network failure, the `Cassandra Datacenter` can be updated manually allowing `Cass Operator` to update nodes. In such a scenario, the changes must also be applied to the `Mission Control Cluster` object. Otherwise the `Mission Control Operator` will revert the changes when the network connection is restored. Note, that such changes should be avoided and done only in exceptional circumstances.

#### Resolution

Monitor the hint count on the active data center. If the hint count increases, the network connection is down and hints are being generated. Once the network connection is restored, the hints are replayed to the passive data center. Refer to [hints monitoring and replay](./hints-monitoring-and-delivery.md) for more details.

#### Toleration

By default the hint window is configured to three days. After this period, hints expire and are discarded, causing the active and passive data centers to be out of sync.

#### How to Recover Out-of-Sync Data Centers

If the outage is longer than hint window size, the hints mechanism is not sufficient to restore consistency. In such a scenario the passive data center must be rebuilt from the active data center. Please refer to [rebuilding data center](datacenter-rebuild.md) procedure.

#### Monitoring

Hints accumulate on the active data center. When the connection is restored, hints replay to the passive data center. Monitor the hint count and ensure it returns to zero after recovery.

### Node Failure

Temporary loss of a single node due to a crash, pod restart, or unplanned maintenance.

![Node Failure](../images/multi-region-dse-container-diagram-combined-CP-node-failure.png)

#### Behavior

The Usage database manages single node loss without affecting availability. Remaining pods continue to serve read and write requests.

#### Resolution

Monitor pod status in the cluster. If a pod is down, it is marked as `down`. The system redistributes data and requests to remaining pods. The database pod restarts automatically when the node is available. If the failure is shorter than hints window size, the hints mechanism is sufficient to restore consistency. Otherwise the consistency must be restored by replacing the failed node. Please refer to [replace node](./rack-rebuild.md#initiating-node-replacement-procedure) section.

#### Toleration

The default hint window is three days. After this period, hints expire and are discarded.

#### Monitoring

Hints for the pod on the failed node accumulate on surviving pods. Once the node is restored, hints replay to it. Monitor the hint count on surviving pods and ensure it returns to zero after recovery. Refer to [hints monitoring](./hints-monitoring-and-delivery.md) for more details.


### Availability Zone Failure

Temporary loss of an AZ due to a cloud provider outage or unplanned maintenance.

![Availability Zone Failure](../images/multi-region-dse-container-diagram-combined-CP-AZ-failure.png)

#### Behavior

The Usage database manages single AZ loss without affecting availability, but the cluster is vulnerable as it runs the minimum pods needed for quorum (2/3).

During the outage, remaining pods continue to serve read and write requests. Write latency increases, so clients may not reach expected throughput. To increase throughput, scale the clients.

Clients read from Kafka topics. If requests time out or take too long, no data is lost, but there is a delay and records accumulate in Kafka topics.

During recovery, pods rejoining the cluster have high CPU usage as they process current traffic and accumulated hints. This is normal. Once hints are consumed, CPU usage stabilizes.

#### Resolution

The operations team should monitor the status of the database pods in the cluster. If an AZ is down, its pods will be marked as `down` in the cluster status. The system automatically redistributes data and requests to the remaining pods.

Investigate the AZ failure with the cloud provider and decide whether to allow recovery or replace the AZ.

**Note:** If the outage is expected to last longer than the hint window (default three days), consider switching to the passive data center, as the active data center is vulnerable to further failures.

If the outage lasts longer than the hint window duration, follow the [rack replacement procedure](./rack-rebuild.md#initiating-rack-replacement-procedure).

#### Toleration

The default hint window is three days. After this, hints expire and are discarded. If the hint window is exceeded, the AZ must be replaced to restore consistency. Survivor pods can process traffic but are vulnerable, as only two of three pods are available and at least two are needed for quorum.

#### Monitoring

Hints for pods that have gone down will accumulate on all of the surviving pods in the data center. Once the AZ is back up and running or replaced, the hints are replayed to it. The operations team should monitor the hint count on the surviving pods and ensure that it returns to zero after the AZ is restored. CPU usage on pods or nodes in the restored AZ will be extremely high for some time after they join the cluster.

### Restoring from backup

The database should be configured with periodic backups. The backup contains schema definition and data for each of the nodes. Please refer to [Medusa configuration](../medusa.md) for information about creating backups.

The backups are taken in each data center separately. They contain a snapshot of data taken at different times. To ensure consistency between the data centers, only a single data center, the one with the most up-to-date backup, should be restored. The other data center should be rebuilt as specified in the [data center rebuild](./datacenter-rebuild.md) procedure.

For information on how to restore a data center from backup please refer to [DataStax Restore Data](https://docs.datastax.com/en/mission-control/administration/control-plane/restore.html).